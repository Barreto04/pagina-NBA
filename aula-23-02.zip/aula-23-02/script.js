window.onload = function() {
    alert("Bem-Vindo á finais históricas da NBA!")
}